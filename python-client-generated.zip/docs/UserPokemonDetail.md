# UserPokemonDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_and_pokemon_relationship_id** | **str** |  | 
**user_id** | **str** |  | [optional] 
**pokemon_id** | **int** |  | [optional] 
**created_at** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

